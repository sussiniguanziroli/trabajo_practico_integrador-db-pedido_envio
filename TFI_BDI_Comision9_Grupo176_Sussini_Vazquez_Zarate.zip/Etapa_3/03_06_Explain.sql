-- Usada para el explain de la consulta 2
EXPLAIN SELECT * FROM PEDIDO WHERE fecha_pedido BETWEEN '2025-01-01' AND '2025-03-31';