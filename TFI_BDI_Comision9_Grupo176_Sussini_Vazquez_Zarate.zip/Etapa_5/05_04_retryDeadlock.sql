-- Retry ante deadlock

USE tpi_pedido_envio;DELIMITER //DROP PROCEDUREIF EXISTS pedido_con_retry //
CREATE PROCEDURE pedido_con_retry( IN p_id_cliente  int,
                                   IN p_id_producto int,
                                   IN p_cantidad    int )
BEGIN
  DECLARE v_intento      int DEFAULT 0;
  declare v_max_intentos int DEFAULT 2; -- 2 reintentos = 3 intentos totales
  declare v_exito        boolean DEFAULT false;
  declare v_codigo_error int;
  declare v_mensaje_error text;
  -- Bucle de reintentos
  INTENTOS:
  WHILE v_intento <= v_max_intentos
  AND
  NOT v_exito do
  SET v_intento = v_intento + 1;
  select concat('Intento ', v_intento, ' de ', v_max_intentos + 1) AS log;
  
  begin
    -- Handler que captura errores
    DECLARE EXIT handler FOR sqlexception
    BEGIN
      get diagnostics condition 1 v_codigo_error = mysql_errno, v_mensaje_error = message_text;
      select concat('ERROR detectado - Código: ', v_codigo_error, ' - Mensaje: ', v_mensaje_error) AS log;
      
      -- Si es DEADLOCK (error 1213)
      if v_codigo_error = 1213 THEN
      IF v_intento <= v_max_intentos THEN
      SELECT 'DEADLOCK detectado. Aplicando backoff de 1 segundo...' AS log;
      
      do sleep(1); -- BACKOFF
      else
      SELECT 'FALLO: Deadlock persistente después de reintentos' AS resultado;
    
    end
    IF;
    else
    -- Otro error: no reintentar
    SELECT concat('ERROR NO RECUPERABLE: ', v_mensaje_error) AS resultado;
    
    set v_intento = v_max_intentos + 1;
  end
  IF;
end;
-- ===== TRANSACCIÓN =====START TRANSACTION;INSERT INTO pedido
            (
                        id_cliente,
                        fecha_pedido,
                        estado_pedido,
                        total
            )
            VALUES
            (
                        p_id_cliente,
                        Now(),
                        'Pendiente',
                        0
            );SET @nuevo_pedido = Last_insert_id();INSERT INTO pedido_producto
            (
                        id_pedido,
                        id_producto,
                        cantidad,
                        precio_unitario,
                        subtotal
            )
SELECT @nuevo_pedido,
       p_id_producto,
       p_cantidad,
       precio_unitario,
       precio_unitario * p_cantidad
FROM   producto
WHERE  id_producto = p_id_producto;UPDATE pedido
SET    total =
       (
              SELECT Sum(subtotal)
              FROM   pedido_producto
              WHERE  id_pedido = @nuevo_pedido)
WHERE  id_pedido = @nuevo_pedido;COMMIT;SET v_exito = true;SELECT Concat('EXITO: Pedido ', @nuevo_pedido, ' registrado en intento ', v_intento, ' - COMMIT ejecutado') 
AS resultado;LEAVE intentos;END;
END WHILE intentos;IF NOT v_exito then
SELECT 'Operación fallida después de todos los intentos' AS resumen;ENDIF;END //
delimiter ;





-- CALL 1
CALL pedido_con_retry(1, 1, 5);



-- CALL 2
CALL pedido_con_retry(999999, 1, 5);


-- Visualizar procedimiento
SHOW CREATE PROCEDURE pedido_con_retry;

