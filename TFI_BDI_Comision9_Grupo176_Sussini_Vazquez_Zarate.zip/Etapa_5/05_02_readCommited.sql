-- READ COMMITTED
-- Preparamos los datos sobre los cuales trabajaremos.
USE tpi_pedido_envio;
INSERT INTO PRODUCTO (id_producto, producto_nombre, producto_codigo, precio_unitario, stock_disponible)
VALUES (8888, 'Producto Aislamiento Test', 'AISL-001', 1000.00, 100)
ON DUPLICATE KEY UPDATE stock_disponible = 50;
 -- Verificar
SELECT * FROM PRODUCTO WHERE id_producto = 8888;

-- SESIÓN 1
USE tpi_pedido_envio;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
START TRANSACTION;
SELECT stock_disponible AS 'Lectura 1'
FROM PRODUCTO
WHERE id_producto = 8888;

-- SESIÓN 2
USE tpi_pedido_envio;
START TRANSACTION;
UPDATE PRODUCTO
SET stock_disponible = 10
WHERE id_producto = 8888;
SELECT 'Actualicé a 50 pero NO hice COMMIT' AS estado;

-- SESIÓN 1
SELECT stock_disponible AS 'Lectura 1'
FROM PRODUCTO
WHERE id_producto = 8888;

-- SESIÓN 2
COMMIT;

-- SESIÓN 1
SELECT stock_disponible AS 'Lectura 1'
FROM PRODUCTO
WHERE id_producto = 8888;

-- SESIÓN 1
COMMIT;






