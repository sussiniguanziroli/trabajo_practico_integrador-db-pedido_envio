-- REPEATABLE READ
-- Previo a la ejecución restauramos los valores de stock
-- SESIÓN 1
UPDATE PRODUCTO
SET stock_disponible = 100
WHERE id_producto = 8888;
COMMIT;
SELECT stock_disponible FROM PRODUCTO WHERE id_producto = 8888;

USE tpi_pedido_envio;
SET TRANSACTION ISOLATION LEVEL REPEATABLE READ;
START TRANSACTION;

-- SESIÓN 2
USE tpi_pedido_envio;
START TRANSACTION;
UPDATE PRODUCTO
SET stock_disponible = 50
WHERE id_producto = 8888;
 COMMIT;
 SELECT 'Actualicé a 50 y ya hice COMMIT' AS estado;

-- SESIÓN 1
SELECT stock_disponible AS 'Lectura 2'
FROM PRODUCTO
WHERE id_producto = 8888;

-- SESIÓN 1
COMMIT;

SELECT stock_disponible AS 'Lectura 3'
FROM PRODUCTO
WHERE id_producto = 8888;