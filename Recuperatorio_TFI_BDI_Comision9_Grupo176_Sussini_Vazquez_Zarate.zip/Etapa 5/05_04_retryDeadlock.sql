USE tpi_pedido_envio;

DROP PROCEDURE IF EXISTS actualizar_stock_retry;

DELIMITER //

CREATE PROCEDURE actualizar_stock_retry(
    IN p_id_producto_1 INT,
    IN p_id_producto_2 INT,
    IN p_cantidad INT
)
BEGIN
    DECLARE v_intento INT DEFAULT 0;
    DECLARE v_max_intentos INT DEFAULT 2;
    DECLARE v_exito BOOLEAN DEFAULT FALSE;
    DECLARE v_codigo_error INT;
    DECLARE v_mensaje_error TEXT;
    
    INTENTOS: WHILE v_intento <= v_max_intentos AND NOT v_exito DO
        SET v_intento = v_intento + 1;
        SELECT CONCAT('Intento ', v_intento, ' de ', v_max_intentos + 1) AS log;
        
        BEGIN
            DECLARE EXIT HANDLER FOR SQLEXCEPTION
            BEGIN
                GET DIAGNOSTICS CONDITION 1 
                    v_codigo_error = MYSQL_ERRNO, 
                    v_mensaje_error = MESSAGE_TEXT;
                
                SELECT CONCAT('ERROR detectado - Código: ', v_codigo_error, 
                             ' - Mensaje: ', v_mensaje_error) AS log;
                
                IF v_codigo_error = 1213 THEN
                    IF v_intento <= v_max_intentos THEN
                        SELECT 'DEADLOCK detectado. Aplicando backoff de 1 segundo...' AS log;
                        DO SLEEP(1);
                    ELSE
                        SELECT 'FALLO: Deadlock persistente después de reintentos' AS resultado;
                    END IF;
                ELSE
                    SELECT CONCAT('ERROR NO RECUPERABLE: ', v_mensaje_error) AS resultado;
                    SET v_intento = v_max_intentos + 1;
                END IF;
            END;
            
            START TRANSACTION;
            
            UPDATE PRODUCTO
            SET stock_disponible = stock_disponible - p_cantidad
            WHERE id_producto = p_id_producto_1;
            
            DO SLEEP(2);
            
            UPDATE PRODUCTO
            SET stock_disponible = stock_disponible - p_cantidad
            WHERE id_producto = p_id_producto_2;
            
            COMMIT;
            
            SET v_exito = TRUE;
            SELECT CONCAT('ÉXITO: Stock actualizado en intento ', v_intento) AS resultado;
            LEAVE INTENTOS;
        END;
    END WHILE INTENTOS;
    
    IF NOT v_exito THEN
        SELECT 'Operación fallida después de todos los intentos' AS resumen;
    END IF;
END;
//

DELIMITER ;