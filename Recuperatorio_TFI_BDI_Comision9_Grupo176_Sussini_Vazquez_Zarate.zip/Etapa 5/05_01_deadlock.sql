-- DEADLOCK
-- Preparamos PRODUCTO para la prueba:
-- SESION 1
USE tpi_pedido_envio;
INSERT INTO PRODUCTO (id_producto, producto_nombre, producto_codigo, precio_unitario, stock_disponible)
VALUES
	(9991, 'Producto A', 'TEST-A', 100.00, 50),
	(9992, 'Producto B', 'TEST-B', 200.00, 50)
ON DUPLICATE KEY UPDATE stock_disponible = 50;

-- SESION 1
USE tpi_pedido_envio;
START TRANSACTION;
UPDATE PRODUCTO SET stock_disponible = stock_disponible - 5 WHERE id_producto = 9991;

-- SESION 2
USE tpi_pedido_envio;
START TRANSACTION;
UPDATE PRODUCTO SET stock_disponible = stock_disponible - 5 WHERE id_producto = 9992;

-- SESION 1
UPDATE PRODUCTO SET stock_disponible = stock_disponible - 5 WHERE id_producto = 9992;

-- SESION 2
UPDATE PRODUCTO SET stock_disponible = stock_disponible - 5 WHERE id_producto = 9991;

-- SESION 1
SHOW ENGINE INNODB STATUS;

-- SESION 2
SHOW ENGINE INNODB STATUS;
