-- ============================================================
-- VERIFICACION EXPLICITA DE INTEGRIDAD REFERENCIAL POST-CARGA
-- ============================================================
USE tpi_pedido_envio;

SELECT 
    'CLIENTE → LOCALIDADES' AS relacion,
    (SELECT COUNT(*) FROM CLIENTE) AS total_registros,
    COUNT(l.id_localidad) AS referencias_validas,
    (SELECT COUNT(*) FROM CLIENTE) - COUNT(l.id_localidad) AS huerfanas,
    CASE 
        WHEN COUNT(l.id_localidad) = (SELECT COUNT(*) FROM CLIENTE) 
        THEN 'OK' 
        ELSE 'REVISAR' 
    END AS estado
FROM CLIENTE c
LEFT JOIN LOCALIDADES l ON c.id_localidad = l.id_localidad

UNION ALL

SELECT 
    'PEDIDO → CLIENTE',
    (SELECT COUNT(*) FROM PEDIDO),
    COUNT(c.id_cliente),
    (SELECT COUNT(*) FROM PEDIDO) - COUNT(c.id_cliente),
    CASE 
        WHEN COUNT(c.id_cliente) = (SELECT COUNT(*) FROM PEDIDO) 
        THEN 'OK' 
        ELSE 'REVISAR'
    END
FROM PEDIDO p
LEFT JOIN CLIENTE c ON p.id_cliente = c.id_cliente

UNION ALL

SELECT 
    'PEDIDO_PRODUCTO → PEDIDO',
    (SELECT COUNT(*) FROM PEDIDO_PRODUCTO),
    COUNT(p.id_pedido),
    (SELECT COUNT(*) FROM PEDIDO_PRODUCTO) - COUNT(p.id_pedido),
    CASE 
        WHEN COUNT(p.id_pedido) = (SELECT COUNT(*) FROM PEDIDO_PRODUCTO) 
        THEN 'OK' 
        ELSE 'REVISAR'
    END
FROM PEDIDO_PRODUCTO pp
LEFT JOIN PEDIDO p ON pp.id_pedido = p.id_pedido

UNION ALL

SELECT 
    'PEDIDO_PRODUCTO → PRODUCTO',
    (SELECT COUNT(*) FROM PEDIDO_PRODUCTO),
    COUNT(pr.id_producto),
    (SELECT COUNT(*) FROM PEDIDO_PRODUCTO) - COUNT(pr.id_producto),
    CASE 
        WHEN COUNT(pr.id_producto) = (SELECT COUNT(*) FROM PEDIDO_PRODUCTO) 
        THEN 'OK' 
        ELSE 'REVISAR'
    END
FROM PEDIDO_PRODUCTO pp
LEFT JOIN PRODUCTO pr ON pp.id_producto = pr.id_producto

UNION ALL

SELECT 
    'ENVIO → PEDIDO',
    (SELECT COUNT(*) FROM ENVIO),
    COUNT(p.id_pedido),
    (SELECT COUNT(*) FROM ENVIO) - COUNT(p.id_pedido),
    CASE 
        WHEN COUNT(p.id_pedido) = (SELECT COUNT(*) FROM ENVIO) 
        THEN 'OK' 
        ELSE 'REVISAR'
    END
FROM ENVIO e
LEFT JOIN PEDIDO p ON e.id_pedido = p.id_pedido;